// import './App.css';
// import DataTable from './DataTable';

// function App() {
//   return (
//     <div className="App">
//       <DataTable />
//     </div>
//   );
// }

// export default App;
import React, { useEffect, useState } from "react";

function App() { 
  const [user, setUser] = useState([]);

  const fetchData = () => {
    return fetch("https://63998da716b0fdad77409a5e.mockapi.io/api/v1/hikers")
          .then((response) => response.json())
          .then((data) => setUser(data));
  }

  useEffect(() => {
    fetchData();
  },[])

  return (
    <main>
      <h1>User List</h1>
      
      <ul>
        {user && user.length > 0 && user.map((userObj, index) => (
            <li key={userObj.id}>{userObj.name}<br/>{userObj.avatar}<br/>Id{userObj.country}<br/>Id{userObj.city}<br/>{userObj.dateOfBirth}</li>
          ))}
      </ul>
    </main>
  );
}

export default App;