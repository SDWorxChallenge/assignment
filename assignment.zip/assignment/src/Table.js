// import React from 'react';
// import axios from 'axios';
// import {useState} from 'react';
// import DataTable from "./sdworx/DataTable.js";
// const [tableData, setTableData] = useState([]);
// useEffect(() => {
//   axios.get('https://63998da716b0fdad77409a5e.mockapi.io/api/v1/hikers')
//     .then(response => {
//       setTableData(response.data);
//     })
//     .catch(error => {
//       console.error(error);
//     });
// }, []);
// <table>
//   <thead>
//     <tr>
//       <th>ID</th>
//       <th>Name</th>
//       <th>Email</th>
//     </tr>
//   </thead>
//   <tbody>
//     {tableData.map(row => (
//       <tr key={row.id}>
//         <td>{row.id}</td>
//         <td>{row.name}</td>
//         <td>{row.email}</td>
//       </tr>
//     ))}
//   </tbody>
// </table>
// export default Table;
// import React from "react";
// import DataTable from "./sdworx/DataTable.js";

// const Table = ({ data }) => {
//   return (
//     <>
//       <table>
//         <thead>
//           <tr>
//             <th>First</th>
//             <th>Last</th>
//             <th>Email</th>
//             <th>Address</th>
//             <th>Created</th>
//             <th>Balance</th>
//           </tr>
//         </thead>
//         <tbody>
//           {data.map((user, key) => (
//             <tr key={key}>
//               <td>{UserList.name}</td>
//               <td>{user.last}</td>
//               <td>{user.email}</td>
//               <td>{user.address}</td>
//               <td>{user.created}</td>
//               <td>{user.balance}</td>
//             </tr>
//           ))}
//         </tbody>
//       </table>
//     </>
//   );
// };

// export default Table;
