import React, { useState } from 'react';
import axios from 'axios';
const [tableData, setTableData] = useState([]);
useEffect(() => {
  axios.get('https://63998da716b0fdad77409a5e.mockapi.io/api/v1/hikers')
    .then(response => {
      setTableData(response.data);
    })
    .catch(error => {
      console.error(error);
    });
}, []);
<table>
  <thead>
    <tr>
      <th>ID</th>
      <th>Name</th>
      <th>Email</th>
    </tr>
  </thead>
  <tbody>
    {tableData.map(row => (
      <tr key={row.id}>
        <td>{row.id}</td>
        <td>{row.name}</td>
        <td>{row.email}</td>
      </tr>
    ))}
  </tbody>
</table>
