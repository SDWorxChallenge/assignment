import * as React from 'react';
import { DataGrid, GridColDef, GridValueGetterParams } from '@mui/x-data-grid';

const columns: GridColDef[] = [
  { field: 'name', headerName: 'Name', width: 130 },
  { field: 'dateOfBirth', headerName: 'Date of birth', width: 130 },
  { field: 'avatar', headerName: 'avatar', width: 130 },
  { field: 'country', headerName: 'country', width: 130 },
  { field: 'city', headerName: 'city', width: 130 },
  { field: 'id', headerName: 'id', width: 130 },
   //add all columns headers likewise
  // ...... last row should render delete button with onClick function
];

const getRows = () =>{
   //store api data in attendieesList 
   let rows = []
   _.map(userList, userList =>{
    const data={
        name : userList.name, //field in column should match key
        dateOfBirth : userList.dateOfBirth,
        avatar:userList.avatar,
        country:userList.country,
        city:userList.city,
        id:userList.id,
        
        


        //map all rows likewise
    }
    rows.push(data)
   })
   return rows
}

export default function DataTable() {
  return (
    <div style={{ height: 400, width: '100%' }}>
      <DataGrid
        rows={getRows}
        columns={columns}
        pageSize={5}
        rowsPerPageOptions={[5]}
        checkboxSelection
      />
    </div>
  );
}